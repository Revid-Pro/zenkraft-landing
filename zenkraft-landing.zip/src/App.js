export default function App() {
  return (
    <main style={{
      minHeight: '100vh',
      background: 'linear-gradient(to bottom right, white, #f1f5f9)',
      color: '#1e293b',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      padding: '2rem',
      fontFamily: 'sans-serif'
    }}>
      <h1 style={{ fontSize: '3rem', fontWeight: 'bold', marginBottom: '1rem' }}>Zenkraft</h1>
      <p style={{ fontSize: '1.25rem', textAlign: 'center', maxWidth: '600px', marginBottom: '2rem' }}>
        Yetenekli freelancer’ların işlerini büyütebildiği, destek gördüğü ve parladığı yaratıcı bir evren.
      </p>
      <div style={{
        backgroundColor: 'white',
        boxShadow: '0 10px 25px rgba(0,0,0,0.1)',
        borderRadius: '1rem',
        padding: '2rem',
        maxWidth: '400px',
        width: '100%',
        textAlign: 'center'
      }}>
        <h2 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}>Yeni sloganımız:</h2>
        <p style={{ fontStyle: 'italic', color: '#4f46e5' }}>"Üret, Büyü, Parılda."</p>
        <button style={{
          marginTop: '1.5rem',
          backgroundColor: '#4f46e5',
          color: 'white',
          padding: '0.5rem 1.5rem',
          borderRadius: '9999px',
          border: 'none',
          fontWeight: '600',
          cursor: 'pointer'
        }}>Erken Erişim İçin Kaydol</button>
      </div>
      <footer style={{ marginTop: '3rem', fontSize: '0.875rem', color: '#94a3b8' }}>
        Remora ekosistemiyle güçlendirilmiştir.
      </footer>
    </main>
  );
}